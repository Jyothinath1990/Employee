package com.controller;

import org.springframework.http.HttpStatus;
import com.model.Employee;
import com.service.EmployeeService;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



import java.util.List;


@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
//    private static List<Employee> employeeService = new ArrayList<>();
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
        if (employee == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Employee details are required.");
        }

        // Check if any field is null
        if (employee.getFirstName() == null || employee.getFirstName().isEmpty()  || employee.getLastName() == null || employee.getLastName().isEmpty()  || employee.getEmail() == null || employee.getEmail().isEmpty() ) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Employee details does not have all required fields.");
        }

        // Check if employee id already exists
        List<Employee> employees = employeeService.getAllEmployees();
        for (Employee emp : employees) {
            if (emp.getFirstName().equals(employee.getFirstName()) && emp.getLastName().equals(employee.getLastName()) && emp.getEmail().equals(employee.getEmail())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Employee with firstName"+ "-" + employee.getFirstName()  + "," +" lastName"+ "-" + employee.getLastName() + "," +" Email"+ "-" + employee.getEmail() + " already exists.");
            }
        }

        employeeService.addEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body("Created Record Succesfully");

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Employee> deleteEmployee(@PathVariable Integer id) {
       Employee employee = employeeService.getEmployeeById(id);

        employeeService.deleteEmployee(id);
        if (employee != null) {
            return ResponseEntity.ok(employee);
        } else {
            return ResponseEntity.notFound().build(); // Employee not found
        }
    }
}
