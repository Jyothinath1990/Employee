package com.service;

import java.util.ArrayList;

import java.util.List;
import org.springframework.stereotype.Service;

import com.model.Employee;

@Service
public class EmployeeService {

    private static List<Employee> employees = new ArrayList<>();
    private static int nextId = 1;

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public Employee addEmployee(Employee employee) {
        employee.setId(nextId++);
        employees.add(employee);
        return employee;
    }

    public void deleteEmployee(Integer id) {
        employees.removeIf(emp -> emp.getId().equals(id));
    }
    
    public Employee getEmployeeById(Integer id) {
        for (Employee employee : employees) {
            if (employee.getId().equals(id)) {
                return employee;
            }
        }
        return null; // Employee not found
    }
}
